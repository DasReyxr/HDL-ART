----------- Code -----------
------ Orlando Reyes ------
--------- Auf Das ---------
------- BoothWallace -------
-------- 04/04/2025 --------
------- Main Library -------
library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.ALL;

--------- Pin/out ---------
entity Multiplier is
	port
		(
        SignA,SignB : in std_logic;
        clk     : in std_logic;
        RA, RB	: in std_logic_vector(7 downto 0);
		P_out	: out std_logic_vector (16-1 downto 0);
		SignP   : out std_logic
        );
end Multiplier;

architecture juve3dstudio of Multiplier is
component Comp 
    port (
        MC : in std_logic_vector(7 downto 0);
        C_S : out std_logic_vector(7 downto 0));
end component;

component Adder16Bits
    port (
        A, B : in std_logic_vector(7 downto 0);
        P : out std_logic_vector(16 downto 0));
end component;
type array8 is array (0 to 7) of std_logic_vector(7 downto 0);
signal  PP : array8;
signal  P : std_logic_vector (7 downto 0);
signal AN, A : std_logic_vector;
begin

    A <= RA(7 downto 0);
        
    Amala: Comp port map( MC => A, C_s => AN);
    P <= A & '0'; -- Meter A como entrada

    -- Sign Handlement --
    SignP <= SignA xor SignB;

    with P(1 downto 0) select 
    PP(0) <= 
        A(15 downto 0)           when "01",
        AN(15 downto 0)          when "10",
        x"0000"   when others;

    with P(2 downto 1) select 
    PP(1) <= 
        A(14 downto 0)  & '0'     when "01",
        AN(14 downto 0) & '0'     when "10",
        x"0000"   when others;

    with P(3 downto 2) select 
    PP(2) <=
        A(13 downto 0)  & "00"     when "01",
        AN(13 downto 0) & "00"     when "10",
        x"0000"   when others;

    with P(4 downto 3) select 
    PP(3) <=
        A(12 downto 0)  & "000"     when "01",
        AN(12 downto 0) & "000"     when "10",
        x"0000"   when others;

    with P(5 downto 4) select 
    PP(4) <=
        A(11 downto 0)  & "0000"     when "01",
        AN(11 downto 0) & "0000"     when "10",
        x"0000"   when others;
    
    with P(6 downto 5) select 
    PP(5) <=
        A(10 downto 0)  & "00000"     when "01",
        AN(10 downto 0) & "00000"     when "10",
        x"0000"   when others;
    
    with P(7 downto 6) select 
    PP(6) <=
        A(9 downto 0)  & "000000"     when "01",
        AN(9 downto 0) & "000000"     when "10",
        x"0000"   when others;
    
    with P(8 downto 7) select 
    PP(7) <=
        A(8 downto 0)  & "0000000"     when "01",
        AN(8 downto 0) & "0000000"     when "10",
        x"0000"   when others;
    
    Psal <= PP(0) + PP(1)+ PP(2) + PP(3) + PP(4) + PP(5) + PP(6) + PP(7);

end juve3dstudio;